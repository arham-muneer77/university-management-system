<?php

$conn = new mysqli("3306", "root", "shahzeb123@", "university_db");


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$searchEmail = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $searchEmail = $_POST["searchEmail"];
}


if ($searchEmail) {
    $sql = "SELECT * FROM students WHERE email LIKE '%$searchEmail%'";
} else {
    $sql = "SELECT * FROM students";
}

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Display Data</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: url(university11.png) no-repeat center center fixed;
            background-size: cover;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            color: #fff;
        }

        .display-container {
            width: 80%;
            padding: 40px;
            background: rgba(0, 0, 0, 0.863);
            border-radius: 15px;
            box-shadow: 0 4px 30px rgb(255, 255, 255);
            border: 1px solid rgba(78, 66, 66, 0.952);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            background-image: linear-gradient(to right, rgba(255, 255, 255, 0.1), rgba(255, 255, 255, 0.2));
            text-align: center;
        }

        .search-box {
            margin-bottom: 20px;
        }

        .search-box input[type="text"] {
            padding: 10px;
            width: 200px;
            border-radius: 5px;
            border: 1px solid #ccc;
            font-size: 16px;
        }

        .search-box input[type="submit"] {
            padding: 10px 20px;
            border: none;
            background: rgba(0, 123, 255, 0.8);
            color: #fff;
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
        }

        .search-box input[type="submit"]:hover {
            background: rgba(0, 123, 255, 1);
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        table, th, td {
            border: 1px solid #fff;
            padding: 10px;
        }

        th {
            background-color: rgba(255, 255, 255, 0.3);
        }

        td {
            background-color: rgba(255, 255, 255, 0.1);
        }
    </style>
</head>
<body>
    <div class="display-container">
        <h2>Display Data</h2>
        <div class="search-box">
            <form action="display.php" method="post">
                <input type="text" name="searchEmail" placeholder="Search by Email">
                <input type="submit" value="Search">
            </form>
        </div>
        <table>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Phone Number</th>
                <th>Action</th>
            </tr>
            <?php
            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row["id"] . "</td>";
                    echo "<td>" . $row["name"] . "</td>";
                    echo "<td>" . $row["email"] . "</td>";
                    echo "<td>" . $row["phone_number"] . "</td>";
                    echo "<td><a href='edit_student.php?id=" . $row["id"] . "'>Edit</a> | <a href='delete_student.php?id=" . $row["id"] . "'>Delete</a></td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='5'>No records found</td></tr>";
            }
            $conn->close();
            ?>
        </table>
    </div>
</body>
</html>
