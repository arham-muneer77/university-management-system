<?php
// Database connection settings
$servername = "3306";
$username = "root";
$password = "shahzeb123@";
$dbname = "university";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $student_name = $_POST['studentName'];
    $id_card = $_POST['idCard'];
    $phone_number = $_POST['phoneNumber'];
    $email = $_POST['email'];

    $sql = "INSERT INTO students (student_name, id_card, phone_number, email) VALUES ('$student_name', '$id_card', '$phone_number', '$email')";

    if ($conn->query($sql) === TRUE) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>
