<?php

$servername = "3306";
$username = "root";
$password = "shahzeb123@";
$dbname = "university";


$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $staff_name = $_POST['staffName'];
    $staff_id = $_POST['staffID'];
    $department = $_POST['department'];
    $phone_number = $_POST['phoneNumber'];
    $email = $_POST['email'];

    $sql = "INSERT INTO staff (staff_name, staff_id, department, phone_number, email) VALUES ('$staff_name', '$staff_id', '$department', '$phone_number', '$email')";

    if ($conn->query($sql) === TRUE) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>
